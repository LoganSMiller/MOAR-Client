﻿using System;
using EFT;

namespace MOAR.AI.Optimization
{
    public class BotOwnerState
    {
        public float Aggression { get; }
        public float SightDistance { get; }

        public BotOwnerState(BotOwner BotOwner)
        {
            Aggression = BotOwner.Aggression;
            SightDistance = BotOwner.SightDistance;
        }

        public override bool Equals(object obj)
        {
            return obj is BotOwnerState other &&
                   Aggression == other.Aggression &&
                   SightDistance == other.SightDistance;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Aggression, SightDistance);
        }
    }
}
