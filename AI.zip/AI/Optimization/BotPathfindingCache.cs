﻿using System.Collections.Generic;
using UnityEngine;
using EFT;


namespace MOAR.AI.Optimization
{
    public class BotOwnerPathfindingCache
    {
        private readonly Dictionary<string, List<Vector3>> _cache = new();

        public List<Vector3> GetOptimizedPath(BotOwner BotOwner, Vector3 destination)
        {
            if (_cache.TryGetValue(BotOwner.Name, out var cachedPath))
            {
                return cachedPath;
            }

            var newPath = CalculatePath(BotOwner, destination);
            _cache[BotOwner.Name] = newPath;
            return newPath;
        }

        private List<Vector3> CalculatePath(BotOwner BotOwner, Vector3 destination)
        {
            return new List<Vector3> { BotOwner.Position, destination };
        }
    }
}
