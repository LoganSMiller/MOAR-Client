﻿using System.Collections.Generic;
using UnityEngine;
using EFT;

namespace MOAR.AI.Optimization
{
    public class BotOwnerGroupOptimization
    {
        public void OptimizeGroupAI(List<BotOwner> BotOwners)
        {
            foreach (var BotOwner in BotOwners)
            {
                if (BotOwner.Grouped)
                {
                    BotOwner.Aggression *= 1.1f;
                    BotOwner.SightDistance = Mathf.Min(300f, BotOwner.SightDistance * 1.25f);
                }
            }
        }
    }
}
