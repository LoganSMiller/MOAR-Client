﻿using EFT;
using UnityEngine;
using System;
using EFT.HealthSystem;

namespace MOAR.AI.Optimization
{
    /// <summary>
    /// Caches critical bot components and state for optimized per-frame access.
    /// </summary>
    public class BotComponentCache : MonoBehaviour
    {
        public BotOwner BotOwner { get; private set; } = null!;
        public IHealthController? Health => _health ??= BotOwner?.GetPlayer?.HealthController;
        public BotMemoryClass? Memory => BotOwner?.Memory;
        public BotPersonalityProfile? Personality { get; set; }

        private IHealthController? _health;
        private bool _initialized;

        public void Initialize(BotOwner owner)
        {
            if (_initialized || owner == null)
                return;

            BotOwner = owner;
            _initialized = true;

            if (TryGetComponent<MOARBotOwner>(out var moar))
            {
                Personality = moar.PersonalityProfile;
            }

            Debug.Log($"[MOAR] BotComponentCache initialized for {BotOwner.Profile?.Nickname}");
        }

        private void OnEnable()
        {
            if (!_initialized && BotOwner == null && TryGetComponent<BotOwner>(out var detected))
            {
                Initialize(detected);
            }
        }

        private void OnDisable()
        {
            BotOwner = null!;
            _health = null;
            Personality = null;
            _initialized = false;
        }

        private void Update()
        {
            if (!_initialized || BotOwner == null || BotOwner.IsDead)
                return;

            // Add per-frame logic here if needed
            // e.g. caching vision data, suppress stats, etc.
        }

        public bool IsAlive()
        {
            return Health?.IsAlive == true;
        }

        public Vector3 GetPosition()
        {
            return BotOwner?.Position ?? transform.position;
        }

        public bool HasValidTarget()
        {
            return Memory?.GoalEnemy?.IsVisible == true;
        }
    }
}
