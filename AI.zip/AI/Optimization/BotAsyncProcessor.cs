﻿using System.Threading.Tasks;
using UnityEngine;
using EFT;

namespace MOAR.AI.Optimization
{
    public class BotOwnerAsyncProcessor
    {
        public async Task ProcessBotOwnerAsync(BotOwner BotOwner)
        {
            await Task.Delay(30); // Simulate async safety without heavy CPU usage
            UpdateBotOwnerBehavior(BotOwner);
        }

        private void UpdateBotOwnerBehavior(BotOwner BotOwner)
        {
            BotOwner.Aggression = Mathf.Clamp(BotOwner.Aggression * 1.1f, 0f, 1f);
        }
    }
}
