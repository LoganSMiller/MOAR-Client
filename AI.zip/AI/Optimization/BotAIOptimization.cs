﻿using System.Collections.Generic;
using EFT;
using UnityEngine;

namespace MOAR.AI.Optimization
{
    public class BotAIOptimization
    {
        // Cache to avoid repeated recalculations
        private readonly Dictionary<string, bool> _optimizationApplied = new();

        public void Optimize(BotOwner botOwner)
        {
            if (botOwner == null || botOwner.Profile == null || botOwner.Memory == null)
                return;

            string botId = botOwner.Profile.Id;

            if (_optimizationApplied.ContainsKey(botId) && _optimizationApplied[botId])
                return;

            // === Vision Optimization ===
            float visionDistance = GetRealisticVision(botOwner);
            if (visionDistance > 0)
            {
                botOwner.LookSensor.SetMaxVisibleDistance(visionDistance);
            }

            // === Hearing Optimization ===
            float hearingDistance = GetRealisticHearing(botOwner);
            if (hearingDistance > 0)
            {
                botOwner.HearingSensor.SetMaxHearingDistance(hearingDistance);
            }

            // === Aggression/Behavior Logic ===
            // Apply behavior tweaks based on role/difficulty
            if (botOwner.BotBrain != null && botOwner.BotBrain.Settings != null)
            {
                float newAggression = GetAggressionModifier(botOwner);
                botOwner.BotBrain.Settings.Aggression = Mathf.Clamp(newAggression, 0.1f, 1f);
            }

            _optimizationApplied[botId] = true;
        }

        private float GetRealisticVision(BotOwner bot)
        {
            if (bot.IsPlayer)
                return 300f; // Players see far
            if (bot.IsBoss())
                return 200f;
            return 120f; // Regular bot range
        }

        private float GetRealisticHearing(BotOwner bot)
        {
            if (bot.IsPlayer)
                return 60f;
            return 40f;
        }

        private float GetAggressionModifier(BotOwner bot)
        {
            if (bot.Profile.Info.Settings.Role.IsFollower)
                return 0.4f;

            if (bot.Profile.Info.Settings.Role.IsBoss)
                return 0.85f;

            return 0.6f;
        }

        public void ResetOptimization(BotOwner botOwner)
        {
            if (botOwner?.Profile == null)
                return;

            _optimizationApplied[botOwner.Profile.Id] = false;
        }
    }

    public static class BotOwnerExtensions
    {
        public static bool IsBoss(this BotOwner botOwner)
        {
            var role = botOwner?.Profile?.Info?.Settings?.Role?.StringValue?.ToLower();
            return role != null && (role.Contains("boss") || role.Contains("knight") || role.Contains("zryachiy"));
        }
    }
}
