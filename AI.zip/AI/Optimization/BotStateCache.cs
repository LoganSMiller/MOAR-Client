﻿using System.Collections.Generic;
using EFT;

namespace MOAR.AI.Optimization
{
    public class BotOwnerStateCache
    {
        private readonly Dictionary<string, BotOwnerState> _cache = new();

        public void CacheBotOwnerState(BotOwner BotOwner)
        {
            if (!_cache.ContainsKey(BotOwner.Name))
            {
                _cache[BotOwner.Name] = new BotOwnerState(BotOwner);
            }
        }

        public void UpdateBotOwnerStateIfNeeded(BotOwner BotOwner)
        {
            var newState = new BotOwnerState(BotOwner);
            if (_cache.TryGetValue(BotOwner.Name, out var lastState) && !lastState.Equals(newState))
            {
                _cache[BotOwner.Name] = newState;
                UpdateBotOwnerAI(BotOwner);
            }
        }

        private void UpdateBotOwnerAI(BotOwner BotOwner)
        {
            BotOwner.RecalculatePathing();
            BotOwner.AdaptToCombat();
        }
    }
}
